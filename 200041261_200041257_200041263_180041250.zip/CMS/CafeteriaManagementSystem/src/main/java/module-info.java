module com.example.cafeteriamanagementsystem {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;

    opens com.example.cafeteriamanagementsystem to javafx.fxml;
    exports com.example.cafeteriamanagementsystem;
}