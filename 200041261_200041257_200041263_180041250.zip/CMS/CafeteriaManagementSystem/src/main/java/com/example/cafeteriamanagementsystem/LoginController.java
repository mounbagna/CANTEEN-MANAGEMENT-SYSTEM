package com.example.cafeteriamanagementsystem;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.ResourceBundle;

public class LoginController implements Initializable {
    @FXML
    private TextField userNameTextField;
    @FXML
    private PasswordField passwordTextField;
    @FXML
    private Button cancelButton;
    @FXML
    private ImageView myImageView;
    HashMap<String,String> loginInfo = new HashMap<>();
    Encryptor encryptor  = new Encryptor();
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        File myFile = new File("images/first page background.PNG");
        Image myImage = new Image(myFile.toURI().toString());
        myImageView.setImage(myImage);
    }
    @FXML
    public void loginButtonOnAction(ActionEvent event) throws IOException, NoSuchAlgorithmException {
        //String username = userNameTextField.getText();
        //String password = passwordTextField.getText();
        //updateLoginUserNamesAndPassword();
        //String encryptedPassword = loginInfo.get(username);
        //if(encryptor.encryptString(password).equals(encryptedPassword) && userNameTextField.getText().isBlank()==false)
        if(userNameTextField.getText().isBlank()==false && passwordTextField.getText().isBlank()==false)
        {
            DatabaseConnection connectNow = new DatabaseConnection();
            Connection connectDB = connectNow.getConnection();

            String verifyLogin = "select count(1) from adminaccount where Name = '" + userNameTextField.getText() + "' AND password = '" + passwordTextField.getText() +"'";
            try{
                Statement statement = connectDB.createStatement();
                ResultSet queryResult = statement.executeQuery(verifyLogin);
                while (queryResult.next()){
                    if(queryResult.getInt(1)==1){
                        //loginMessageLabel.setText("Logged in sucessfully.");
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Login Confirmation Message");
                        alert.setHeaderText("ADMIN LOGIN");
                        alert.setContentText("Logged in sucessfully.");
                        alert.showAndWait();

                        userNameTextField.setText("");
                        passwordTextField.setText("");

                        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AdminMenu.fxml"));
                        Scene scene = new Scene(fxmlLoader.load());

                        Node oldButton =(Node) event.getSource () ;
                        Stage myStage = (Stage)oldButton.getScene().getWindow();
                        myStage.setScene(scene);
                        myStage.show();

                    }else{
                        //loginMessageLabel.setText("Oops! Invalid Login, Please try again.");
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Registration Error Message");
                        alert.setHeaderText("CUSTOMER REGISTRATION");
                        alert.setContentText("Oops! Invalid Login, Please try again.");
                        alert.showAndWait();

                        passwordTextField.setText("");
                    }
                }
            }catch ( Exception e)
            {
                e.printStackTrace();
                e.getCause();
            }
        }
        else
        {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Login Error Message");
            alert.setHeaderText("ADMIN LOGIN");
            alert.setContentText("Please enter your user name and password");
            alert.showAndWait();
        }
    }
    public void cancelButtonOnAction(){
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }
    @FXML
    public void BackBtn(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Welcomescreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load());

        Node oldButton =(Node) event.getSource () ;
        Stage myStage = (Stage)oldButton.getScene().getWindow();
        myStage.setScene(scene);
        myStage.show();
    }
}